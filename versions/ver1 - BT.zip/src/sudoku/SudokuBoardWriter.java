package sudoku;
import cspSolver.BTSolver;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;


public class SudokuBoardWriter {

	public static void writeFile(BTSolver solver, String filePath, long totalStartTime, long acProcessStartTime, long acProcessEndTime, String status)
	{
		try {
			File file = new File(filePath);
			
			if (!file.exists()) {
				file.createNewFile();
			}
			
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			
			bw.write("TOTAL_START=" + String.format("%.3f", (totalStartTime/1000.0)) + "\n");
			bw.write("PREPROCESSING_START=" + String.format("%.3f", acProcessStartTime/1000.0) + "\n");
			bw.write("PREPROCESSING_DONE=" + String.format("%.3f", (acProcessEndTime - acProcessStartTime)/1000.0) + "\n");
			bw.write("SEARCH_START=" + String.format("%.3f", solver.getStartTime()/1000.0) + "\n");
			bw.write("SEARCH_DONE=" + String.format("%.3f", solver.getEndTime()/1000.0) + "\n");
			bw.write("SOLUTION_TIME=" + String.format("%.3f", solver.getTimeTaken()/1000.0) + "\n");
			bw.write("STATUS=" + status + "\n");
			bw.write("SOLUTION=" + solution(solver.getSolution()) + "\n");
			bw.write("COUNT_NODES=" + solver.getNumAssignments() + "\n");
			bw.write("COUNT_DEADENDS=" + solver.getNumBacktracks() + "\n");
			
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static String solution(SudokuFile sudoku) {
		StringBuilder sb = new StringBuilder();
		
		sb.append("(");
		for(int i = 0; i < sudoku.getN(); i ++)
		{
			for(int j = 0; j < sudoku.getN(); j++)
			{
				if (i != 0 || j != 0) {
					sb.append(",");
				}
				sb.append(sudoku.getBoard()[j][i]);
			}
		}
		sb.append(")");
		
		return sb.toString();
	}
}