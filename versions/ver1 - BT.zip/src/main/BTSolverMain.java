package main;

import cspSolver.BTSolver;
import cspSolver.BTSolver.ConsistencyCheck;
import cspSolver.BTSolver.ValueSelectionHeuristic;
import cspSolver.BTSolver.VariableSelectionHeuristic;
import sudoku.SudokuBoardReader;
import sudoku.SudokuBoardWriter;
import sudoku.SudokuFile;

public class BTSolverMain {

	public static void main(String[] args)
	{
		long totalStartTime = System.currentTimeMillis();
		SudokuFile sf = SudokuBoardReader.readFile(args[0]);
		BTSolver solver = new BTSolver(sf);
		String status = "success";
		
		long acProcessStartTime = System.currentTimeMillis();
		long acProcessEndTime = System.currentTimeMillis();
		
		solver.setConsistencyChecks(ConsistencyCheck.None);
		solver.setValueSelectionHeuristic(ValueSelectionHeuristic.None);
		solver.setVariableSelectionHeuristic(VariableSelectionHeuristic.None);
		
		Thread t1 = new Thread(solver);
		try
		{
			t1.start();
			t1.join(Long.parseLong(args[2]));
			if(t1.isAlive())
			{
				status = "timeout";
				t1.interrupt();
			}
		}catch(Exception e)
		{
			status = "error";
		}

//		solver.printSolverStats();
//		System.out.println(solver.getSolution());	
//		System.out.println(sf);
		SudokuBoardWriter.writeFile(solver, args[1], totalStartTime, acProcessStartTime, acProcessEndTime, status);
	}
}
