package cspSolver;

public class VariableSelectionException extends Exception{ 

	private static final long serialVersionUID = 7945806622953610761L;

	public VariableSelectionException (String message)
	{
		super(message);
	}
}
